#ifndef CLIB_RAMDRIVE_PROTOS_H
#define CLIB_RAMDRIVE_PROTOS_H


/*
**	$VER: ramdrive_protos.h 34.106 (20.03.2022)
**
**	C prototypes.
**
**	Copyright � 2022 
**	All Rights Reserved
*/

#ifndef  EXEC_TYPES_H
#include <exec/types.h>
#endif

STRPTR KillRAD0(void);

#endif	/*  CLIB_RAMDRIVE_PROTOS_H  */
